<?php
echo "Ola from PHP";
