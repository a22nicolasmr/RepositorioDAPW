## Escenario web con cliente

Neste escenario, podemos escoller os nomes que queiramos para o servidor web, sendo sempre resoltos desde o cliente

Podemos lanzar un navegador web no cliente, neste caso firefox con 

 docker compose exec cliente firefox-esr

 Este navegador executase dentro do cliente, e será capaz de acceder a http://www.proba.lan/

 Lembrarse sempre de poñer a barra ao final para evitar a búsqueda no google

 