ABOUT UMAMI
-----------

Umami is the theme used for the "Umami food magazine" demonstration site.

ABOUT DRUPAL THEMING
--------------------

See https://www.drupal.org/docs/theming-drupal for more information on Drupal
theming.
