WHAT IS THIS DIRECTORY FOR?
--------------------------------
This directory is for templates previously inherited from the Classy theme.

WHY WERE CLASSY TEMPLATES COPIED HERE?
-------------------------------------------
Classy was removed in Drupal 10. To prepare for Classy's removal, templates that
would otherwise be inherited from Classy are copied here.
